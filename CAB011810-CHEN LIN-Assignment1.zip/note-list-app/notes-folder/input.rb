# assign user input to a variable
user_input = gets.chomp

# call to_i method to convert user input into integer
user_input = gets.chomp.to_i

# call to_f method to convert user input into float
user_input = gets.chomp.to_f
